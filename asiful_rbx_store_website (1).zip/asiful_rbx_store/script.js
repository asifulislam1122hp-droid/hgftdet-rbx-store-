/*
  ASIFUL RBX STORE configuration.
  Replace the placeholder values below before publishing.
  Do not add passwords, PINs, OTPs, or Roblox login credentials to this site.
*/
const STORE_CONFIG = {
  bkashNumber: "YOUR-BKASH-NUMBER",
  nagadNumber: "YOUR-NAGAD-NUMBER",
  whatsappNumber: "8801XXXXXXXXX", // country code + number, digits only
  discordInvite: "https://discord.gg/YOUR-INVITE"
};

document.getElementById("year").textContent = new Date().getFullYear();
document.getElementById("bkashText").textContent = STORE_CONFIG.bkashNumber;
document.getElementById("nagadText").textContent = STORE_CONFIG.nagadNumber;
document.getElementById("discordLink").href = STORE_CONFIG.discordInvite;
document.getElementById("whatsappLink").href =
  "https://wa.me/" + STORE_CONFIG.whatsappNumber.replace(/\D/g, "") +
  "?text=" + encodeURIComponent("Hi ASIFUL RBX STORE, I want to ask about a Robux order.");

const packageSelect = document.getElementById("package");
document.querySelectorAll(".package-card").forEach(card => {
  card.addEventListener("click", () => {
    document.querySelectorAll(".package-card").forEach(c => c.classList.remove("selected"));
    card.classList.add("selected");
    const rbx = Number(card.dataset.rbx).toLocaleString("en-US");
    packageSelect.value = `${rbx} R$ — ${card.dataset.price}`;
    document.getElementById("order").scrollIntoView({behavior: "smooth", block: "start"});
  });
});
document.querySelector('.package-card[data-rbx="250"]').classList.add("selected");

document.querySelectorAll(".copy-btn").forEach(button => {
  button.addEventListener("click", async () => {
    const value = button.dataset.copy === "bkash" ? STORE_CONFIG.bkashNumber : STORE_CONFIG.nagadNumber;
    try {
      await navigator.clipboard.writeText(value);
      button.textContent = "Copied!";
      setTimeout(() => button.textContent = "Copy", 1400);
    } catch {
      button.textContent = value;
    }
  });
});

document.getElementById("orderForm").addEventListener("submit", event => {
  event.preventDefault();
  const username = document.getElementById("username").value.trim();
  const gamepass = document.getElementById("gamepass").value.trim();
  const payment = document.getElementById("payment").value;
  const reference = document.getElementById("reference").value.trim();
  if (!/^https?:\/\/(www\.)?roblox\.com\//i.test(gamepass)) {
    document.getElementById("formStatus").textContent = "Please enter a Roblox gamepass URL.";
    return;
  }
  const message = [
    "Hi ASIFUL RBX STORE, I want to place an order.",
    "Package: " + packageSelect.value,
    "Roblox username: " + username,
    "Gamepass URL: " + gamepass,
    "Payment method: " + payment,
    reference ? "Payment reference: " + reference : ""
  ].filter(Boolean).join("\n");
  const status = document.getElementById("formStatus");
  status.textContent = "Order message prepared. Choose Discord or WhatsApp below and paste the message. No payment was processed.";
  const wa = document.getElementById("whatsappLink");
  wa.href = "https://wa.me/" + STORE_CONFIG.whatsappNumber.replace(/\D/g, "") + "?text=" + encodeURIComponent(message);
  wa.textContent = "Send order on WhatsApp ↗";
  const discord = document.getElementById("discordLink");
  discord.href = STORE_CONFIG.discordInvite;
  try { navigator.clipboard.writeText(message); status.textContent += " Message copied to clipboard."; } catch {}
});
