# ASIFUL RBX STORE

A static, mobile-first Robux order website template. It does **not** process payments or deliver Robux automatically.

## Edit before publishing

Open `script.js` and replace:
- `YOUR-BKASH-NUMBER`
- `YOUR-NAGAD-NUMBER`
- `8801XXXXXXXXX` with your WhatsApp number (digits only, include country code)
- `https://discord.gg/YOUR-INVITE` with your Discord invite

Edit package names and sample prices in `index.html` in both the package cards and the order form. The current prices are sample placeholders; check your actual pricing and any applicable platform fees before publishing.

## Preview on your phone

The easiest way is to upload the folder to a static hosting service, or open `index.html` in a browser after downloading/extracting the ZIP. Some browser features such as clipboard copy work best on HTTPS.

## Free hosting options

### GitHub Pages
1. Sign in to GitHub and create a new public repository, e.g. `asiful-rbx-store`.
2. Upload `index.html`, `styles.css`, `script.js`, and `README.md` to the repository root.
3. Open **Settings → Pages**.
4. Under the build/deployment section, choose **Deploy from a branch**, select `main` and `/ (root)`, then save.
5. Wait for GitHub Pages to publish and use the URL shown in Settings → Pages.

### Netlify (manual deploy)
1. Open Netlify and sign in.
2. Choose the option to add/deploy a site manually.
3. Upload the extracted website folder (or drag the files into the deploy area, depending on the current interface).
4. Use the generated URL to test the site.

## Important safety notes
- This is a static website: order details are not stored in a database. The form prepares a message for the customer to send manually.
- No payment is processed by the website. Confirm payment independently before delivering anything.
- Never request or collect Roblox passwords, email passwords, PINs, one-time codes, or login QR codes.
- Make sure your delivery method and listing comply with Roblox's current Terms and rules. Never promise an automatic delivery or timing that you cannot guarantee.
- Only publish payment details you own or are authorized to use.
- Add a clear refund, delivery, and contact policy before taking customer orders.
